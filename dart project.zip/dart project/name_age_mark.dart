import 'dart:io';

void main() {
  // Declare variables
  String name;
  int age;
  String course;
  int marks1, marks2, marks3, totalMarks;

  print('Enter student name:');
  name = stdin.readLineSync() ?? '';

  print('Enter student age:');
  age = int.parse(stdin.readLineSync() ?? '0');

  print('Enter course name:');
  course = stdin.readLineSync() ?? '';

  print('Enter marks for subject 1:');
  marks1 = int.parse(stdin.readLineSync() ?? '0');

  print('Enter marks for subject 2:');
  marks2 = int.parse(stdin.readLineSync() ?? '0');

  print('Enter marks for subject 3:');
  marks3 = int.parse(stdin.readLineSync() ?? '0');
  totalMarks = marks1 + marks2 + marks3;
  print('\nStudent Details:');
  print('Name: $name');
  print('Age: $age');
  print('Course: $course');
  print('Marks in Subject 1: $marks1');
  print('Marks in Subject 2: $marks2');
  print('Marks in Subject 3: $marks3');
  print('Total Marks: $totalMarks');
}
