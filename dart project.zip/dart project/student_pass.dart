import 'dart:io';

void main() {
  print('Enter the student marks (0-100):');
  

  String? input = stdin.readLineSync();
  

  int? marks = int.tryParse(input ?? '');

  if (marks == null || marks < 0 || marks > 100) {
    print('Please enter a valid mark between 0 and 100.');
    return;
  }

  if (marks < 18) {
    print('Result: Fail');
  } else {
    print('Result: Pass');
  }
}
