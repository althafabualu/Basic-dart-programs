import 'dart:io';

void main() {
  print('Enter a three-digit number:');
  
 
  String? input = stdin.readLineSync();

  int? number = int.tryParse(input ?? '');

  if (number == null || number < 100 || number > 999) {
    print('Please enter a valid three-digit number.');
    return;
  }
  int sum = (number ~/ 100) + ((number ~/ 10) % 10) + (number % 10);
  print('Sum of the digits: $sum');
}
