void main() {
  print('Odd numbers between 100 and 599:');

  // Loop through numbers from 100 to 599
  for (int i = 100; i <= 599; i++) {
    // Check if the number is odd
    if (i % 2 != 0) {
      print(i);
    }
  }
}
